/* Diuu Birthday Website — extracted JavaScript */

(() => {
  let current = 1;
  let audioCtx = null;
  let playing = false;
  let timer = null;

  const steps = Array.from(document.querySelectorAll('.step'));
  const dots = Array.from(document.querySelectorAll('.dot'));
  const soundBtn = document.getElementById('sound');
  const toast = document.getElementById('toast');
  const reasons = [
    "Because your smile can make even an ordinary day feel special. 💗",
    "Because you know how to make people laugh when they need it most. 🥹✨",
    "Because you're caring, genuine, and always worth celebrating. 🌸",
    "Because your presence makes memories more beautiful. 🦋",
    "Because you're simply YOU — and that's more than enough. 💖"
  ];

  function show(n) {
    current = Math.max(1, Math.min(4, n));
    steps.forEach((el, i) => el.classList.toggle('active', i === current - 1));
    dots.forEach((el, i) => el.classList.toggle('active', i <= current - 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function nextStep() { show(current + 1); }

  function ensureAudio() {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!audioCtx) audioCtx = new AC();
    if (audioCtx.state === 'suspended') audioCtx.resume();
  }

  function tone(freq, duration = .18, volume = .06) {
    if (!audioCtx) return;
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.frequency.value = freq;
    o.type = 'sine';
    g.gain.setValueAtTime(.0001, audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(volume, audioCtx.currentTime + .02);
    g.gain.exponentialRampToValueAtTime(.0001, audioCtx.currentTime + duration);
    o.connect(g).connect(audioCtx.destination);
    o.start();
    o.stop(audioCtx.currentTime + duration);
  }

  function playMelody(notes, speed=.38, volume=.07, onDone=null) {
    ensureAudio();
    if (!audioCtx) return;
    clearInterval(timer);
    playing = true;
    soundBtn.textContent = '🎵';
    let i = 0;
    tone(notes[0], .28, volume);
    timer = setInterval(() => {
      i++;
      if (i >= notes.length) {
        clearInterval(timer); playing = false;
        if (onDone) onDone();
        return;
      }
      tone(notes[i], .3, volume);
    }, speed * 1000);
  }

  function startMusic() {
    playMelody([523,659,784,659,880,784,659,523,587,659,784,659], .34, .045);
  }

  function toggleMusic() {
    if (!playing) startMusic();
    else { clearInterval(timer); playing = false; soundBtn.textContent = '🔇'; }
  }

  // Original Song 1: playful birthday-pop theme for the balloon step
  function balloonTheme() {
    playMelody([523,659,784,988,880,784,659,523,587,698,880,784,659,523], .25, .065, () => {
      pulseEmojis();
    });
  }

  function birthdayTune() {
    playMelody([392,392,440,392,523,494,392,392,440,392,587,523], .30, .075);
  }

  // Original Song 2: softer cinematic finale theme
  function themeSong() {
    playMelody([523,587,659,784,659,587,523,440,523,659,784,880,784,659,587,523,659,784,988,880,784,659,523], .36, .075, celebrate);
    pulseEmojis();
  }

  function pulseEmojis() {
    const icons = ['💗','✨','🦋','🌸','🎀','💕','🌷','⭐'];
    icons.forEach((x, i) => {
      const e = document.createElement('span');
      e.className = 'sparkle';
      e.textContent = x;
      e.style.left = (8 + i * 12) + 'vw';
      e.style.bottom = '-30px';
      e.style.animationDelay = (i * .2) + 's';
      document.body.appendChild(e);
      setTimeout(() => e.remove(), 5600);
    });
  }

  function celebrate() {
    ensureAudio();
    tone(784, .2, .08);
    for (let i = 0; i < 45; i++) {
      const e = document.createElement('span');
      e.className = 'confetti';
      e.textContent = ['🎉','💖','✨','🎀','🥳','💕','🌸','🦋','⭐'][Math.floor(Math.random()*9)];
      e.style.left = Math.random() * 100 + 'vw';
      e.style.top = '-30px';
      e.style.animationDelay = Math.random() * .7 + 's';
      document.body.appendChild(e);
      setTimeout(() => e.remove(), 3500);
    }
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2200);
  }

  function blow() {
    document.querySelectorAll('.flame').forEach(x => x.textContent = '💨');
    ensureAudio();
    tone(330,.3,.08);
    setTimeout(() => tone(262,.3,.08),160);
  }

  function fireworks() {
    for (let i = 0; i < 12; i++) setTimeout(celebrate, i * 90);
  }

  function popBalloon(el, i) {
    if (el.dataset.popped) return;
    el.dataset.popped = '1';
    ensureAudio();
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width/2, cy = r.top + r.height/2;
    const flash = document.createElement('span');
    flash.className = 'balloon-pop-flash'; flash.style.left = cx + 'px'; flash.style.top = cy + 'px';
    document.body.appendChild(flash); setTimeout(() => flash.remove(), 260);
    const ring = document.createElement('span');
    ring.className = 'balloon-pop-ring'; ring.style.left = cx + 'px'; ring.style.top = cy + 'px';
    document.body.appendChild(ring); setTimeout(() => ring.remove(), 650);
    el.classList.add('pop');
    tone(260 + i * 65, .12, .1);
    document.getElementById('reason').textContent = reasons[i];
    ['💥','✨','💗','🎀','⭐','💕','🦋','🌸','🥳','💫'].forEach((emoji, n) => {
      const p = document.createElement('span');
      p.className = 'balloon-pop-particle'; p.textContent = emoji;
      p.style.left = (r.left + r.width/2) + 'px'; p.style.top = (r.top + r.height/2) + 'px';
      p.style.setProperty('--dx', ((n%2?1:-1) * (35 + Math.random()*85)) + 'px');
      p.style.setProperty('--dy', ((n<5?-1:1) * (25 + Math.random()*95)) + 'px');
      document.body.appendChild(p); setTimeout(() => p.remove(), 1000);
    });
    ['💖','✨','🎀'].forEach((emoji,n)=>{
      const p=document.createElement('span'); p.className='pop-letter'; p.textContent=emoji;
      p.style.left=cx+'px'; p.style.top=cy+'px';
      p.style.setProperty('--dx', ((n-1)*70)+'px'); p.style.setProperty('--dy', (-70-Math.random()*55)+'px');
      document.body.appendChild(p); setTimeout(()=>p.remove(),950);
    });
    setTimeout(() => el.remove(), 220);
  }

  function openMysteryBox(){
    const box = document.getElementById('openBtn');
    if (box.classList.contains('opening')) return;
    box.classList.add('opening');
    ensureAudio();
    startMusic();
    tone(523,.12,.08);
    setTimeout(() => tone(659,.12,.08), 100);
    setTimeout(() => tone(784,.2,.08), 200);
    celebrate();
    setTimeout(() => { nextStep(); balloonTheme(); }, 700);
  }
  document.getElementById('openBtn').addEventListener('click', openMysteryBox);
  document.getElementById('openBtn').addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openMysteryBox(); }
  });
  document.getElementById('step2Btn').addEventListener('click', () => { birthdayTune(); nextStep(); });
  document.getElementById('cakeBtn').addEventListener('click', () => {
    ensureAudio(); birthdayTune();
    for (let i = 0; i < 10; i++) setTimeout(celebrate, i * 55);
    nextStep();
  });
  const revealScenes = Array.from(document.querySelectorAll('.reveal-scene'));
  let revealIndex = 0;
  function revealTo(n) {
    revealIndex = Math.max(0, Math.min(revealScenes.length - 1, n));
    revealScenes.forEach((el, i) => el.classList.toggle('active', i === revealIndex));
    window.scrollTo({top:0, behavior:'smooth'});
    if (revealIndex === 3) fireworks();
  }
  document.getElementById('revealStart').addEventListener('click', () => { ensureAudio(); tone(523,.2,.07); revealTo(1); });
  document.getElementById('continueReveal1').addEventListener('click', () => { ensureAudio(); tone(659,.2,.07); revealTo(2); });
  document.getElementById('openLetter').addEventListener('click', () => {
    document.getElementById('letter').classList.add('open');
    document.getElementById('letterSeal').textContent='✨';
    document.getElementById('continueReveal2').classList.add('show');
    tone(784,.3,.07); celebrate();
  });
  document.getElementById('continueReveal2').addEventListener('click', () => { revealTo(3); fireworks(); themeSong(); });
  document.getElementById('finalBtn').addEventListener('click', () => { themeSong(); fireworks(); });
  document.getElementById('replayBtn').addEventListener('click', () => { revealIndex=0; document.getElementById('letter').classList.remove('open'); document.getElementById('continueReveal2').classList.remove('show'); document.getElementById('letterSeal').textContent='💌'; revealTo(0); });
  soundBtn.addEventListener('click', toggleMusic);

  const ba = document.getElementById('balloons');
  ['b1','b2','b3','b4','b5'].forEach((c, i) => {
    const b = document.createElement('div');
    b.className = 'balloon ' + c;
    b.style.animationDelay = (i * .18) + 's';
    b.addEventListener('click', () => popBalloon(b, i));
    ba.appendChild(b);
  });

  show(1);
})();
